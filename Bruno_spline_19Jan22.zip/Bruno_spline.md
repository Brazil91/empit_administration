# Spline
## 18Jan22
Wichtig | Dringend | Description |
-------|-------|--------------------------|
 x | x | Bug im connected Modus
 x |   | Axen Homogenisierung in allen Fenstern; doppelte x Achse; em + l in m; Axenbeschriftung |
 x |   | DoC Tool like em Tool |

## 19Jan22
### Wichtig+Dringend im Rahmen von Astora
#### Scheiterung der Optimierung auf den relevanten frequenzen
![[Pasted image 20220119145317.png]]
2021-12-15_2_001_AS3
#### Zweites Spline Segment nicht modifizierbar
2021-12-15_2_001_AS2
#### Menschliche Kompensation in relation zu den Residuen sowie Fit-Ergebnissen

![[Pasted image 20220119144808.png]]
2021-12-15_1_001_AS1: Fit-Ergebnisse 

![[Pasted image 20220119144910.png]]
2021-12-15_1_001_AS1: Splinekompensation