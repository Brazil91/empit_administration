# Weekly Report KW 14

Datum: 8Apr22

## RMR

> Als Onboarding Projekt genutzt

> [https://empit-pathfinder-rmr.herokuapp.com/](RMR-Pathfinder-App)
> ID: john126
> PW: matrix126

[x] Ausgewertet
    - sehr tiefe Pipeline 4 m im Schnitt
    - maximale Tiefe beträgt 6.8 m 
    - 2 Düker
    - Export
        * **Es fehlt ein Bogen, wo die zwei Splines miteinander verbunden werden** 
[  ] Review
[x] App Erstellt
    - PO und PDatum fehlt
[x] Report erstellt 


![](Weekly_report_KW14_DL_8Apr22_assets/2022-04-08-15-07-55-image.png)

## Entwicklung eines Image processing scripts für das RoW Feature

- Gebündeltes Umbennen der Empit Bilder bzw. der Empit Meter die den Namen der Bilder repäsentieren

- Resizing der Bilder auf small und thumbnail größe

- Mapping der Bilder zu den Daten



### Optimierung der Pathfinderapp

Optimierung des bend_fullangle features

- Filterintervall im Tooltip title

Beginn der Weiterentwicklung des Right of Way (RoW) features



## ACVG Schulung

Datum: 8Abr22, 10:00 Uhr

Supervisor: Albin

Anwesende: Marius, Timothy, Daniel

Informationen vorerst in "klatte" in das *Knowledgemanagement* Dokument, festgehalten

## Onboarding Timothy

- Software overview
  
  - elab handling, 
    
    - "Wo ist was?"
    
    - Welche fit panels werden für die pre evaluation (live) benötigt?
    
    - Welche fit Ergebnisse sind sehr wichtig bei der Geometrieauswertung?
      
      - Korrelation/Antikorrelation der fit Ergebnisse, wie sind diese in Bezug auf die Geometrie zu berücksichtigen 
    
    - Wie erkennt man Metallteile?
    
    - Wie lädt man einen bereits berechneten Spline?
    
    - WIe lädt man den Spline in/aus der lokalen oder remote db? 
    
    - Wie setzt man Anomalien?
    
    - Wie erkennt man ein schlechtes SNR?
    
    - WIe mach ich einen Export?
      
      - single
      
      - "Connected Splines"
        
        - Worauf ist vor dem Export in diesem Modus zu achten, Stichwort Intermediet Splines
      
      - pipeline_exporter
        
        - Welche values müssen bei Rover oder Curentmapper exportiert werden
        
        - Wo stelle ich die Schrittweite ein
  
  - rclone how to

- Optimierung/Korrektur des derzeitigen Spline Skripts
  
  - Im Rahmen der Optimierung, Erklärung der Spline Parameter Basics

- Berechnung von Splines

- Standards in Bezug auf die Datenstruktur, für die Projektbearbeitung

- *.epr handling mit VS Code
  
  - bspw. pipe diameter eines Managers ändern

- Post processing
  
  - Wie ist es Aufgebaut?
  
  - Wie konfiguriert man es Kundenspezifisch?
  
  - troubleshooting
    
    - Wie kann man vorgehen

- Patfinder app
  
  - Erläuterung aller Konfigurationsdatein, die für eine Kundenapp anzupassen sind
  
  - Wie ist die Pathinder-App Struktur auf der backend Seite und auf der Projektebene
  
  - troubleshooting, wenn mal ein Feature nicht funktioniert, wie sollte man vorgehen
